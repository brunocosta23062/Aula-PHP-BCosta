<?php
session_start();

// Verifica login
if (!isset($_SESSION['logado']) || $_SESSION['logado'] == FALSE) {
    echo "<script>alert('Por favor, faça o login'); window.location.href='../index.php';</script>";
    exit;
}
?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Cadastro de Filmes</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS INTERNO -->
    <style>
        body {
            background: linear-gradient(135deg, #1e1e2f, #2a2a40);
            font-family: Arial, sans-serif;
            color: #fff;
        }

        .container {
            margin-top: 40px;
        }

        .form-box {
            background: #2f2f4f;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 0px 25px rgba(0,0,0,0.6);
        }

        h1 {
            font-weight: bold;
        }

        label {
            font-weight: 500;
        }

        .form-control, select {
            background-color: #1e1e2f;
            border: 1px solid #444;
            color: #fff;
        }

        .form-control:focus {
            background-color: #1e1e2f;
            color: #fff;
            border-color: #6c63ff;
            box-shadow: none;
        }

        textarea {
            resize: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #6c63ff, #4a47a3);
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-primary:hover {
            transform: scale(1.05);
            background: linear-gradient(135deg, #7d74ff, #5a57c3);
        }
    </style>

</head>

<body>

<div class="container">

    <?php require "../includes/topo.php"; ?>

    <div class="form-box">

        <h1 class="text-center mb-4">🎬 Cadastrar Filmes</h1>

        <form action="../Services/validacao.php" method="post">

            <div class="row" style="margin-left: 10%;">
                
                <div class="col-md-4 mb-3">
                    <label>Título</label>
                    <input type="text" class="form-control" name="titulo" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label>Ano</label>
                    <input type="number" class="form-control" name="ano">
                </div>

                <div class="col-md-3 mb-3">
                    <label>Gênero</label>
                    <input type="text" class="form-control" name="genero">
                </div>

                <div class="col-md-4 mb-4">
                    <label>Classificação</label>
                    <input type="text" class="form-control" name="classificacao">
                </div>

                <div class="col-md-4 mb-4">
                    <label>Diretor</label>
                    <input type="text" class="form-control" name="diretor">
                </div>

                <div class="col-md-3 mb-3">
                    <label>Status</label>
                    <select class="form-control" name="status">
                        <option value="Ativo">Ativo</option>
                        <option value="Inativo">Inativo</option>
                    </select>
                </div>
            <div class="row" style="margin-left: 18%;">
                <div class="col-md-6 mb-3">
                    <label>Sinopse</label>
                    <textarea class="form-control" name="sinopse"></textarea>
                </div>
            </div>
                

            </div>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary w-50">
                    🚀 Cadastrar Filme
                </button>
            </div>

        </form>

    </div>

    <?php require "../includes/rodape.php"; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>