<?php
session_start();

if (!isset($_SESSION['logado']) || $_SESSION['logado'] == FALSE) {
    echo "<script>alert('Por favor, faça o login'); window.location.href='../index.php';</script>";
    exit;
}

require "../Controller/Action_SQL.php";

$nova_selecao = new Action_SQL;
$resultado = $nova_selecao->selecionar();
?>

<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Filmes</title>

    <style>
        body {
            background-color: #f5f6fa;
        }

        .container {
            margin-top: 30px;
        }

        h1 {
            font-weight: bold;
        }

        .table-container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.1);
        }

        table {
            margin-top: 20px;
        }

        th {
            background-color: #343a40;
            color: white;
            text-align: center;
        }

        td {
            text-align: center;
            vertical-align: middle;
        }

        .btn {
            border-radius: 8px;
            padding: 5px 10px;
        }

        .btn-primary {
            background-color: #4e73df;
            border: none;
        }

        .btn-danger {
            background-color: #e74a3b;
            border: none;
        }

        .badge-alugado {
            background-color: #28a745;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }

        .badge-livre {
            background-color: #6c757d;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }
    </style>

</head>

<body>

<div class="container">

    <?php require "../Includes/topo.php"; ?>

    <h1 class="text-center mb-4 mt-4">🎬 Filmes da Locadora</h1>

    <div class="table-container">

        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Status</th>
                    <th>Locador</th>
                    <th>Ações</th>
                </tr>
            </thead>

            <tbody>
                <?php while($row = $resultado->fetch(PDO::FETCH_ASSOC)) : ?>

                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['nome']; ?></td>
                    <td><?= $row['descricao']; ?></td>

                    <td>
                        <?php if($row['alugado'] == 1): ?>
                            <span class="badge-alugado">Alugado</span>
                        <?php else: ?>
                            <span class="badge-livre">Livre</span>
                        <?php endif; ?>
                    </td>

                    <td><?= $row['locador']; ?></td>

                    <td>
                        <a class="btn btn-primary btn-sm" href="editar.php?id=<?= $row['id']; ?>">
                            ✏️ Editar
                        </a>

                        <a class="btn btn-danger btn-sm"
                           href="../Services/deletar.php?id=<?= $row['id']; ?>"
                           onclick="return confirm('Tem certeza que deseja deletar?')">
                            🗑️ Deletar
                        </a>
                    </td>
                </tr>

                <?php endwhile; ?>
            </tbody>
        </table>

    </div>

    <?php require "../includes/rodape.php"; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>