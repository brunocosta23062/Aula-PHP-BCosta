<?php
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>aula 6</title>
  </head>
  <style>

    #caixa{

        height: 600px;
        width: 600px;
    }

        #img{

            width: 30%;
            height: 30%;
            margin-top: 10%;
            margin-bottom: 10%;
            margin-right: 10%;
            margin-left: 10%;
        }  
       



         

  </style>
  <body>

   <div class="container">

        <div class="row">
            <div id="caixaTopo" class="col-md-12">
                <ul class="nav justify-content-center">
                    <div class="nav-item">
                        <a class="nav-link active"  href="home.php">Inicío</a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link" href="cadastro.php">Cadastro Cliente</a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link" href="cadastro_fornecedor.php">Cadastro Fornecedor</a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link" href="informacao.php">Sobre</a>
                    </div>
                     <div class="nav-item">
                        <a class="nav-link" href="sair.php">Sair</a>
                    </div>
                </ul>   
            </div>
        </div>

  </div>























    
  

  </body>
</html>